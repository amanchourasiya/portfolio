from django.apps import AppConfig


class PortConfig(AppConfig):
    name = 'port'
