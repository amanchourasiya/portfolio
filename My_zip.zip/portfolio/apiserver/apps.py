from django.apps import AppConfig


class ApiserverConfig(AppConfig):
    name = 'apiserver'
