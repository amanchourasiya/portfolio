import EditorJs from '@editorjs/editorjs';



const editor= new EditorJs(
{
	

	
}
)